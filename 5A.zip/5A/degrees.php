<?php

	
	$degree= $_POST['option'];
	 if(empty($degree))

  {

    echo("");

  }
  else

  {

    $N = count($degree);

    for($i=0; $i < $N; $i++)
    {
      echo($degree[$i] . " ");
    }
  }


?>
