<?php

	
	echo $_GET['bloodgroup'];
?>
