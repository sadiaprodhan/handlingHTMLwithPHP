<?php

	
	echo $_GET['gender'];
?>
