<?php

	
	echo $_GET['dd']."/".$_GET['mm']."/".$_GET['yyyy'];
	

?>
